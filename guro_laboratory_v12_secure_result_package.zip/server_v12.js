// Guro Laboratory V12 - secure result portal + SMS provider adapter starter
const express=require("express"),cors=require("cors"),crypto=require("crypto"),fs=require("fs"),path=require("path"),helmet=require("helmet"),rateLimit=require("express-rate-limit");
const app=express(),PORT=process.env.PORT||3000,DATA=path.join(__dirname,"guro-v12-data.json"),SESSION_MS=8*60*60*1000;
const SMS_URL=process.env.SMS_URL||"",SMS_API_KEY=process.env.SMS_API_KEY||"",SMS_SENDER=process.env.SMS_SENDER||"GURO";
const PUBLIC_RESULT_URL=process.env.PUBLIC_RESULT_URL||"http://localhost:3000/result.html";
const hash=s=>crypto.createHash("sha256").update(String(s)).digest("hex"), token=()=>crypto.randomBytes(32).toString("hex");
function initial(){return{staff:[{id:"S-001",username:"admin",passwordHash:hash("1234"),role:"admin"}],patients:[],results:[],sessions:{},audit:[],sms:[]}}
function load(){if(!fs.existsSync(DATA))return initial();try{return JSON.parse(fs.readFileSync(DATA,"utf8"))}catch{return initial()}}
function save(d){fs.writeFileSync(DATA,JSON.stringify(d,null,2))}
function clean(v,n=200){return String(v??"").trim().slice(0,n)}
function audit(d,a,action,detail){d.audit.push({time:new Date().toISOString(),actor:a,action,detail})}
function maskPhone(p){p=String(p);return p.length>4?p.slice(0,-4).replace(/./g,"*")+p.slice(-4):"****"}
async function sendSMS(phone,message){
 if(!SMS_URL||!SMS_API_KEY)return {sent:false,mode:"not_configured"};
 try{const r=await fetch(SMS_URL,{method:"POST",headers:{"Content-Type":"application/json","Authorization":"Bearer "+SMS_API_KEY},body:JSON.stringify({to:phone,from:SMS_SENDER,message})});const body=await r.text();return r.ok?{sent:true,mode:"provider"}:{sent:false,mode:"provider_error",status:r.status,response:body.slice(0,300)}}catch(e){return {sent:false,mode:"network_error",message:e.message}}
}
app.use(helmet());app.use(cors());app.use(express.json({limit:"1mb"}));app.use(rateLimit({windowMs:15*60*1000,max:300}));
function auth(req,res,next){const t=req.headers.authorization?.replace(/^Bearer\s+/,""),d=load(),s=t&&d.sessions[t];if(!s||Date.now()>s.expires)return res.status(401).json({error:"Authentication required"});req.staff=s;req.sessionToken=t;next()}
function role(...rs){return(req,res,next)=>rs.includes(req.staff.role)?next():res.status(403).json({error:"Insufficient permission"})}

app.use(express.static(__dirname));
app.get("/api/health",(q,s)=>s.json({ok:true,service:"Guro Laboratory V12",smsConfigured:!!(SMS_URL&&SMS_API_KEY)}));
app.post("/api/login",(q,s)=>{let d=load(),u=clean(q.body?.username,60),p=String(q.body?.password??""),st=d.staff.find(x=>x.username===u&&x.passwordHash===hash(p));if(!st)return s.status(401).json({error:"Invalid login"});let t=token();d.sessions[t]={staffId:st.id,username:st.username,role:st.role,expires:Date.now()+SESSION_MS};audit(d,u,"LOGIN","Successful");save(d);s.json({token:t,staff:{id:st.id,username:st.username,role:st.role}})});
app.post("/api/logout",auth,(q,s)=>{let d=load();audit(d,req.staff.username,"LOGOUT","Session ended");delete d.sessions[req.sessionToken];save(d);s.json({ok:true})});
app.get("/api/data",auth,(q,s)=>{let d=load();s.json({patients:d.patients,results:d.results,sms:d.sms.slice(-100)})});
app.post("/api/patients",auth,role("admin","technologist","reception"),(q,s)=>{let d=load(),x=q.body||{},name=clean(x.name,120),phone=clean(x.phone,30);if(!name||!phone)return s.status(400).json({error:"Name and phone required"});let p={id:"P-"+String(d.patients.length+1).padStart(5,"0"),name,phone,sex:clean(x.sex,20),age:clean(x.age,10),date:new Date().toISOString()};d.patients.push(p);audit(d,req.staff.username,"PATIENT_CREATE",p.id);save(d);s.status(201).json(p)});
app.post("/api/results",auth,role("admin","technologist"),(q,s)=>{let d=load(),x=q.body||{};if(!x.pid||!x.test||x.value===undefined)return s.status(400).json({error:"Required fields missing"});let r={id:"GL-"+String(d.results.length+10001).padStart(5,"0"),pid:clean(x.pid,30),type:clean(x.type,50),test:clean(x.test,100),value:clean(x.value,100),unit:clean(x.unit,40),ref:clean(x.ref,100),comment:clean(x.comment,300),status:"Pending",otp:"",date:new Date().toISOString()};d.results.push(r);audit(d,req.staff.username,"RESULT_CREATE",r.id);save(d);s.status(201).json(r)});
app.post("/api/results/:id/ready",auth,role("admin","technologist"),async(q,s)=>{let d=load(),r=d.results.find(x=>x.id===q.params.id);if(!r)return s.status(404).json({error:"Not found"});let p=d.patients.find(x=>x.id===r.pid);if(!p)return s.status(404).json({error:"Patient not found"});r.status="Ready";r.otp=String(crypto.randomInt(100000,1000000));r.readyAt=new Date().toISOString();audit(d,req.staff.username,"RESULT_READY",r.id);const link=PUBLIC_RESULT_URL+"?id="+encodeURIComponent(r.id);const message=`ጉሮ ላብራቶሪ: ውጤትዎ ተዘጋጅቷል። Result ID: ${r.id}. Secure link: ${link}  OTP ደግሞ በዚህ SMS አልተላከም፤ በተለየ መንገድ ይላክ።`;const sms=await sendSMS(p.phone,message);d.sms.push({time:new Date().toISOString(),resultId:r.id,patientId:p.id,to:maskPhone(p.phone),status:sms.sent?"SENT":"NOT_SENT",mode:sms.mode});audit(d,req.staff.username,"SMS_NOTIFICATION",r.id+" "+sms.mode);save(d);s.json({id:r.id,status:r.status,otp:r.otp,sms,publicLink:link})});
app.post("/api/results/verify",(q,s)=>{let d=load(),id=clean(q.body?.id,40),otp=clean(q.body?.otp,10),r=d.results.find(x=>x.id===id);if(!r||r.status!=="Ready"||r.otp!==otp)return s.status(401).json({error:"Invalid Result ID or OTP"});let p=d.patients.find(x=>x.id===r.pid);if(!p)return s.status(404).json({error:"Patient not found"});s.json({patient:{name:p.name,age:p.age,sex:p.sex},result:{id:r.id,type:r.type,test:r.test,value:r.value,unit:r.unit,ref:r.ref,comment:r.comment,date:r.date}})});
app.get("/api/sms/log",auth,role("admin","reception"),(q,s)=>s.json(load().sms.slice(-200)));
app.get("/api/audit",auth,role("admin"),(q,s)=>s.json(load().audit));
app.listen(PORT,()=>console.log("Guro Laboratory V12: http://localhost:"+PORT));
